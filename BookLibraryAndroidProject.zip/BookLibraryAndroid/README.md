# Book Library Android project

This project skeleton is configured for the supplied Kotlin Jetpack Compose source.

## Included
- `app/src/main/java/com/example/booklibrary/MainActivity.kt` — the provided source with the `ExperimentalFoundationApi` opt-in patch.
- `app/build.gradle.kts` — Android/Compose/PDFBox dependencies.
- `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`
- `app/src/main/AndroidManifest.xml`
- `.github/workflows/build-apk.yml` — builds a debug APK on GitHub Actions.

## Build
Push the project to a GitHub repository on `main` or `master`, then open **Actions** and download the artifact `book-library-debug-apk`.

## Important
This is a best-fit Gradle configuration based on the Kotlin source supplied. I have not run a real Android Gradle build in this environment, so the first GitHub Actions run is still needed to confirm compatibility. If it fails, send the complete error section above `BUILD FAILED` (not only `Process completed with exit code 1`).

The source uses `MANAGE_EXTERNAL_STORAGE` for broad PDF scanning on Android 11+. Android/Google Play restricts this permission; for Play Store publication, consider replacing broad scanning with Android's document picker/MediaStore approach.
